
# DriveDecision AI
### Explainable Vehicle Purchase Recommendation Engine

DriveDecision AI is a machine learning project that evaluates vehicle
configurations using purchasing price, maintenance cost, passenger
capacity, luggage boot size, number of doors and safety level.

It predicts one of four historical evaluation categories:
- Unacceptable
- Acceptable
- Good
- Very Good

## Problem Statement

Vehicle evaluation involves multiple factors. This project explores
how machine learning can learn patterns between vehicle attributes
and historical evaluation labels.

## Dataset

Source: UCI Machine Learning Repository

Dataset: Car Evaluation
https://archive.ics.uci.edu/dataset/19/car+evaluation

The dataset contains 1,728 records and six input attributes.

## Features

| Feature | Description |
|---|---|
| buying | Buying price |
| maint | Maintenance cost |
| doors | Number of doors |
| persons | Passenger capacity |
| lug_boot | Luggage boot size |
| safety | Safety level |
| class | Historical evaluation target |

## Technologies

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- SQLite
- Joblib

## Machine Learning Models

1. Dummy Classifier baseline
2. Decision Tree
3. Random Forest
4. Logistic Regression

## Workflow

1. Dataset collection
2. Data cleaning
3. Exploratory Data Analysis
4. Categorical preprocessing
5. Stratified train-test split
6. Model training
7. Five-fold cross-validation
8. Classification evaluation
9. Feature importance
10. Decision tree interpretation
11. SQLite analysis
12. Interactive vehicle evaluation

## Evaluation Metrics

- Accuracy
- Macro Precision
- Macro Recall
- Macro F1-score
- Weighted F1-score
- Confusion Matrix

Actual results are available in outputs/reports.

## Explainability

A shallow decision tree is used to provide human-readable decision
rules. Feature importance is also exported.

## Interactive Prediction

The notebook includes an evaluate_vehicle() function that accepts
vehicle configuration attributes and returns a predicted category
and model probabilities.

## Repository Structure

- notebook/: Google Colab notebook
- data/: Raw and cleaned dataset
- models/: Saved classifier
- outputs/visualizations/: Charts
- outputs/reports/: Evaluation reports
- outputs/vehicle_analysis.db: SQLite database

## How to Run

1. Open the notebook in Google Colab.
2. Run the complete notebook.
3. The dataset is downloaded automatically.
4. Models, reports and visualizations are generated.
5. Use evaluate_vehicle() to test vehicle configurations.

## Limitations

- This dataset contains historical categorical evaluation labels.
- These labels are not actual vehicle safety ratings.
- The dataset is not representative of every modern vehicle market.
- Model predictions should not be treated as professional purchase
  advice or official safety certification.
- Model performance must be evaluated on unseen records.

## Future Improvements

- Build a Streamlit interface.
- Add real vehicle specifications.
- Compare with independent vehicle safety ratings.
- Add more vehicle-market datasets.
- Develop a model monitoring workflow.

## Author

Aditya Dhage

## Disclaimer

Educational machine learning prototype. Not an official vehicle
safety evaluation or financial purchase recommendation.
